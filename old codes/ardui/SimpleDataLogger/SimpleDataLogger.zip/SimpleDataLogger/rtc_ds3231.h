
#ifndef __rtc_3231_h_
#define __rtc_3231_h_

void parse_cmd(char *cmd, int cmdsize);

#endif

