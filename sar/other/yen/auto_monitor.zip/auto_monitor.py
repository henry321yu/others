import numpy as np
import json
import os
import sys
import time
import csv
import glob

class ArcSARMonitor:
    def __init__(self, config_path):
        # 1. 讀取設定
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except Exception as e:
            print(f"[Error] 無法讀取設定檔: {e}")
            sys.exit(1)
        
        self.indices = self.config['monitor_indices']
        self.threshold = self.config['threshold_mm']
        self.coh_thr = self.config.get('coherence_threshold', 0.3)
        self.log_dir = "logs"
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        # 2. 頻率與轉換因子
        try:
            fc_val = self.config['fc_start']
            bw_val = self.config['bw']
        except KeyError:
            print("[Error] Config 缺少 fc_start 或 bw 參數")
            sys.exit(1)

        c = 299792458
        f_center = fc_val + (bw_val / 2)
        self.factor = (-c * 1000) / (4 * np.pi * f_center)

        print(f"[{time.strftime('%H:%M:%S')}] 系統初始化... (模式: 5分鐘間隔自動過濾)")

    def read_binary_file(self, filepath, dtype=np.float32):
        if not os.path.exists(filepath): return None
        try:
            return np.fromfile(filepath, dtype=dtype)
        except: return None

    def save_to_csv(self, filename, max_val, avg_val, is_alarm):
        current_month = time.strftime("%Y-%m")
        log_path = os.path.join(self.log_dir, f"{current_month}_Report.csv")
        file_exists = os.path.isfile(log_path)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        status = "ALARM" if is_alarm else "NORMAL"
        
        try:
            with open(log_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                if not file_exists:
                    writer.writerow(["Timestamp", "Status", "Filename", "Max_Rebound_mm", "Avg_Rebound_mm", "Threshold_mm"])
                writer.writerow([timestamp, status, filename, f"{max_val:.4f}", f"{avg_val:.4f}", self.threshold])
        except Exception as e:
            print(f"[Error] CSV 寫入失敗: {e}")

    # --- 新增功能：檢查這是不是第二幅影像 (Scan 2) ---
    def is_scan_2(self, current_file_path):
        """
        邏輯：檢查資料夾中，依時間排序的前一個檔案。
        如果 (當前檔案時間 - 前一個檔案時間) 在 3~7 分鐘之間，
        則判定當前檔案為 Scan 2 (Base)，需要執行計算。
        否則判定為 Scan 1 (Monitor) 或其他，忽略之。
        """
        # 1. 取得資料夾路徑
        folder_path = os.path.dirname(os.path.abspath(current_file_path))
        
        # 2. 抓出所有 .dphase 檔
        all_files = glob.glob(os.path.join(folder_path, "*.dphase"))
        
        # 3. 依照「修改時間」排序 (舊 -> 新)
        # 為什麼用修改時間？因為下載程式剛下載完，修改時間通常就是下載時間
        all_files.sort(key=os.path.getmtime)
        
        # 4. 找到當前檔案在列表中的位置
        try:
            # 這裡用 abspath 確保路徑格式一致
            abs_current = os.path.abspath(current_file_path)
            # 轉換列表中的路徑為絕對路徑以進行比對
            all_files_abs = [os.path.abspath(f) for f in all_files]
            
            curr_index = all_files_abs.index(abs_current)
        except ValueError:
            print("[Info] 檔案列表比對失敗，略過。")
            return False

        # 如果這是第一個檔案，肯定不是 Scan 2
        if curr_index == 0:
            print(f"[{os.path.basename(current_file_path)}] 是資料夾中的第一個檔案 -> 視為 Scan 1 (忽略)")
            return False
            
        # 5. 抓出前一個檔案
        prev_file = all_files[curr_index - 1]
        
        # 6. 計算時間差 (秒)
        curr_time = os.path.getmtime(current_file_path)
        prev_time = os.path.getmtime(prev_file)
        time_diff = curr_time - prev_time
        
        print(f"[檢查] 與前一檔案 ({os.path.basename(prev_file)}) 時間差: {time_diff:.1f} 秒")
        
        # 7. 判斷邏輯 (設定寬容度，例如 200秒 ~ 400秒，涵蓋 5分鐘)
        if 200 < time_diff < 420: # 3.3分 ~ 7分
            print("   -> 時間差符合 5分鐘法則，判定為 Scan 2 (基準圖)。開始計算！")
            return True
        else:
            print("   -> 時間差不符合 (可能是 Scan 1 或下一輪的開始)。忽略不計。")
            return False

    def process_rebound(self, diff_dphase_path):
        
        # *** 在計算前，先執行身分查驗 ***
        if not self.is_scan_2(diff_dphase_path):
            return False # 提早結束，不報錯，只是不計算

        # --- 以下計算邏輯不變 ---
        dphi_data = self.read_binary_file(diff_dphase_path)
        if dphi_data is None: return False

        try:
            max_idx = len(dphi_data)
            valid_indices = [i for i in self.indices if i < max_idx]
            if not valid_indices: return False

            displacements = dphi_data[valid_indices] * self.factor
            max_rebound = np.max(np.abs(displacements)) 
            avg_rebound = np.mean(np.abs(displacements))
            
            is_alarm = max_rebound > self.threshold
            
            print(f"[{time.strftime('%H:%M:%S')}] 分析結果 | Max: {max_rebound:.3f} mm | Avg: {avg_rebound:.3f} mm")
            self.save_to_csv(os.path.basename(diff_dphase_path), max_rebound, avg_rebound, is_alarm)
            
            return is_alarm

        except Exception as e:
            print(f"[Error] 計算錯誤: {e}")
            return False

if __name__ == "__main__":
    if len(sys.argv) < 3:
        # sys.exit(0) 不會報錯，DELL 認為執行成功
        sys.exit(0)

    config_path = sys.argv[1]
    target_file = sys.argv[2]

    monitor = ArcSARMonitor(config_path)
    alarm = monitor.process_rebound(target_file)
    
    if alarm:
        print("!!! 警報 !!!")
        sys.exit(1)
    else:
        sys.exit(0)