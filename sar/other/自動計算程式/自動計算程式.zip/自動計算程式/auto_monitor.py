import numpy as np
import json
import os
import sys
import time
import csv  # 新增：用於處理 CSV 檔案

class ArcSARMonitor:
    def __init__(self, config_path):
        # 1. 讀取設定
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except Exception as e:
            print(f"[Error] 無法讀取設定檔: {e}")
            sys.exit(1)
        
        self.indices = self.config['monitor_indices']
        self.threshold = self.config['threshold_mm']
        self.coh_thr = self.config.get('coherence_threshold', 0.3)
        
        # 設定 Log 存放資料夾 (預設在程式同一層的 logs 資料夾)
        self.log_dir = "logs"
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        # 2. 直接從 Config 讀取頻率參數 (依照您的最佳實踐)
        try:
            fc_val = self.config['fc_start']
            bw_val = self.config['bw']
        except KeyError:
            print("[Error] Config 缺少 fc_start 或 bw 參數")
            sys.exit(1)

        c = 299792458
        f_center = fc_val + (bw_val / 2)
        self.factor = (-c * 1000) / (4 * np.pi * f_center)

        print(f"[{time.strftime('%H:%M:%S')}] 系統就緒. 模式: 彈性回彈監測 + CSV紀錄")

    def read_binary_file(self, filepath, dtype=np.float32):
        if not os.path.exists(filepath):
            print(f"[Error] 找不到檔案: {filepath}")
            return None
        try:
            return np.fromfile(filepath, dtype=dtype)
        except Exception as e:
            print(f"[Error] 讀取錯誤: {e}")
            return None

    def save_to_csv(self, filename, max_val, avg_val, is_alarm):
        """
        將結果寫入 CSV 檔案
        """
        # 1. 產生依月份命名的 Log 檔名 (例如: logs/2025-12_Report.csv)
        current_month = time.strftime("%Y-%m")
        log_path = os.path.join(self.log_dir, f"{current_month}_Report.csv")
        
        # 2. 檢查檔案是否已存在 (若不存在，等一下要寫標題)
        file_exists = os.path.isfile(log_path)
        
        # 3. 準備資料
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        status = "ALARM" if is_alarm else "NORMAL"
        
        try:
            # 使用 'a' (append) 模式開啟，這樣不會覆蓋舊資料
            with open(log_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # 如果是新檔案，先寫入標題列
                if not file_exists:
                    header = ["Timestamp", "Status", "Filename", "Max_Rebound_mm", "Avg_Rebound_mm", "Threshold_mm"]
                    writer.writerow(header)
                
                # 寫入本次數據
                writer.writerow([timestamp, status, filename, f"{max_val:.4f}", f"{avg_val:.4f}", self.threshold])
                
            print(f"   -> 紀錄已儲存至: {log_path}")
            
        except Exception as e:
            print(f"[Error] 寫入 CSV 失敗: {e}")

    def process_rebound(self, diff_dphase_path):
        """
        核心功能: 分析回彈量
        """
        dphi_data = self.read_binary_file(diff_dphase_path)
        
        if dphi_data is None:
            return False

        try:
            max_idx = len(dphi_data)
            valid_indices = [i for i in self.indices if i < max_idx]
            
            if not valid_indices:
                print("[Error] Index 超出範圍")
                return False

            dphi_values = dphi_data[valid_indices]
            displacements = dphi_values * self.factor
            
            # 取絕對值 (只看變形幅度)
            max_rebound = np.max(np.abs(displacements)) 
            avg_rebound = np.mean(np.abs(displacements))
            
            is_alarm = max_rebound > self.threshold
            
            # 輸出螢幕 Log
            status_text = "ALARM" if is_alarm else "NORMAL"
            print(f"[{time.strftime('%H:%M:%S')}] {status_text} | Max: {max_rebound:.3f} mm | File: {os.path.basename(diff_dphase_path)}")
            
            # *** 關鍵新增：寫入 CSV ***
            self.save_to_csv(os.path.basename(diff_dphase_path), max_rebound, avg_rebound, is_alarm)
            
            return is_alarm

        except Exception as e:
            print(f"[Error] 計算錯誤: {e}")
            return False

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python auto_monitor_final_v2.py <config_path> <diff_dphase_file>")
        sys.exit(0)

    config_path = sys.argv[1]
    target_file = sys.argv[2]

    monitor = ArcSARMonitor(config_path)
    alarm = monitor.process_rebound(target_file)
    
    if alarm:
        print("!!! 軌道彈性變形量異常 (超標) !!!")
        sys.exit(1)
    else:
        sys.exit(0)